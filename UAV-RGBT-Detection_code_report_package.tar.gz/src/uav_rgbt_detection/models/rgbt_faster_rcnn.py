from __future__ import annotations

from collections import OrderedDict
from typing import List, Optional

import torch
from torch import nn
from torchvision.models.detection import FasterRCNN
from torchvision.models.detection.anchor_utils import AnchorGenerator
from torchvision.models.detection.image_list import ImageList
from torchvision.models.detection.rpn import RPNHead
from torchvision.ops import MultiScaleRoIAlign

from uav_rgbt_detection.models.rgbt_backbone import RGBTBackboneWithFPN


class RGBTTransform(nn.Module):
    def __init__(self, image_mean_rgb=None, image_std_rgb=None, image_mean_tir=None, image_std_tir=None) -> None:
        super().__init__()
        self.image_mean_rgb = image_mean_rgb or [0.485, 0.456, 0.406]
        self.image_std_rgb = image_std_rgb or [0.229, 0.224, 0.225]
        self.image_mean_tir = image_mean_tir or [0.5, 0.5, 0.5]
        self.image_std_tir = image_std_tir or [0.25, 0.25, 0.25]

    @staticmethod
    def _batch_images(images: List[torch.Tensor], size_divisible: int = 32) -> torch.Tensor:
        max_size = [max(s) for s in zip(*[img.shape for img in images])]
        stride = float(size_divisible)
        max_size[1] = int((max_size[1] + stride - 1) // stride * stride)
        max_size[2] = int((max_size[2] + stride - 1) // stride * stride)
        batch_shape = [len(images)] + max_size
        batched = images[0].new_zeros(batch_shape)
        for img, pad_img in zip(images, batched):
            pad_img[: img.shape[0], : img.shape[1], : img.shape[2]].copy_(img)
        return batched

    def normalize(self, image: torch.Tensor, mean, std) -> torch.Tensor:
        mean_t = torch.tensor(mean, dtype=image.dtype, device=image.device)[:, None, None]
        std_t = torch.tensor(std, dtype=image.dtype, device=image.device)[:, None, None]
        return (image - mean_t) / std_t

    def forward(self, rgbs: List[torch.Tensor], tirs: List[torch.Tensor], targets=None):
        rgbs = [self.normalize(img, self.image_mean_rgb, self.image_std_rgb) for img in rgbs]
        tirs = [self.normalize(img, self.image_mean_tir, self.image_std_tir) for img in tirs]
        image_sizes = [img.shape[-2:] for img in rgbs]
        rgb_batch = self._batch_images(rgbs)
        tir_batch = self._batch_images(tirs)
        return (
            ImageList(rgb_batch, image_sizes),
            ImageList(tir_batch, image_sizes),
            targets,
        )

    def postprocess(self, result, image_sizes, original_image_sizes):
        return result


class RGBTFasterRCNN(nn.Module):
    def __init__(
        self,
        num_classes: int,
        pretrained_backbone: bool = True,
        anchor_sizes: tuple[tuple[int, ...], ...] | None = None,
        aspect_ratios: tuple[tuple[float, ...], ...] | None = None,
        fusion_variant: str = "basic",
        neck_variant: str = "fpn",
    ) -> None:
        super().__init__()
        backbone = RGBTBackboneWithFPN(
            pretrained=pretrained_backbone,
            out_channels=256,
            fusion_variant=fusion_variant,
            neck_variant=neck_variant,
        )
        anchor_sizes = anchor_sizes or ((8,), (16,), (32,), (64,), (128,))
        aspect_ratios = aspect_ratios or ((0.5, 1.0, 2.0),) * len(anchor_sizes)
        anchor_generator = AnchorGenerator(
            sizes=anchor_sizes,
            aspect_ratios=aspect_ratios,
        )
        roi_pooler = MultiScaleRoIAlign(featmap_names=["0", "1", "2", "3"], output_size=7, sampling_ratio=2)
        detector = FasterRCNN(
            backbone=backbone,
            num_classes=num_classes,
            rpn_anchor_generator=anchor_generator,
            box_roi_pool=roi_pooler,
            min_size=512,
            max_size=640,
            image_mean=[0.0, 0.0, 0.0],
            image_std=[1.0, 1.0, 1.0],
        )
        detector.rpn.head = RPNHead(backbone.out_channels, anchor_generator.num_anchors_per_location()[0])
        self.detector = detector
        self.transform = RGBTTransform()

    def forward(self, rgbs: List[torch.Tensor], tirs: List[torch.Tensor], targets: Optional[List[dict]] = None):
        original_image_sizes = [img.shape[-2:] for img in rgbs]
        rgb_images, tir_images, targets = self.transform(rgbs, tirs, targets)
        features = self.detector.backbone(rgb_images.tensors, tir_images.tensors)
        if isinstance(features, torch.Tensor):
            features = OrderedDict([("0", features)])
        proposals, proposal_losses = self.detector.rpn(rgb_images, features, targets)
        detections, detector_losses = self.detector.roi_heads(features, proposals, rgb_images.image_sizes, targets)
        detections = self.transform.postprocess(detections, rgb_images.image_sizes, original_image_sizes)
        losses = {}
        losses.update(detector_losses)
        losses.update(proposal_losses)
        if self.training:
            return losses
        return detections


def build_model(
    num_classes: int,
    pretrained_backbone: bool = True,
    anchor_sizes: tuple[tuple[int, ...], ...] | None = None,
    aspect_ratios: tuple[tuple[float, ...], ...] | None = None,
    fusion_variant: str = "basic",
    neck_variant: str = "fpn",
) -> RGBTFasterRCNN:
    return RGBTFasterRCNN(
        num_classes=num_classes,
        pretrained_backbone=pretrained_backbone,
        anchor_sizes=anchor_sizes,
        aspect_ratios=aspect_ratios,
        fusion_variant=fusion_variant,
        neck_variant=neck_variant,
    )
