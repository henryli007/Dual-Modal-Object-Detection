from __future__ import annotations

from collections import OrderedDict

import torch
from torch import nn
from torchvision.models import ResNet50_Weights, resnet50
from torchvision.models._utils import IntermediateLayerGetter
from torchvision.ops import FeaturePyramidNetwork
from torchvision.ops.feature_pyramid_network import LastLevelMaxPool


def _make_resnet50(weights: bool) -> nn.Module:
    return resnet50(weights=ResNet50_Weights.IMAGENET1K_V2 if weights else None, norm_layer=nn.BatchNorm2d)


class ChannelAttention(nn.Module):
    def __init__(self, channels: int, reduction: int = 16) -> None:
        super().__init__()
        hidden = max(channels // reduction, 16)
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.mlp = nn.Sequential(
            nn.Conv2d(channels, hidden, kernel_size=1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden, channels, kernel_size=1, bias=False),
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        avg_out = self.mlp(self.avg_pool(x))
        max_out = self.mlp(self.max_pool(x))
        return self.sigmoid(avg_out + max_out)


class SpatialAttention(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.conv = nn.Conv2d(2, 1, kernel_size=7, padding=3, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        return self.sigmoid(self.conv(torch.cat([avg_out, max_out], dim=1)))


class FusionBlock(nn.Module):
    def __init__(self, channels: int) -> None:
        super().__init__()
        self.rgb_gate = nn.Sequential(
            nn.Conv2d(channels * 2, channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, kernel_size=1),
            nn.Sigmoid(),
        )
        self.tir_gate = nn.Sequential(
            nn.Conv2d(channels * 2, channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, kernel_size=1),
            nn.Sigmoid(),
        )
        self.refine = nn.Sequential(
            nn.Conv2d(channels * 2, channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, rgb: torch.Tensor, tir: torch.Tensor) -> torch.Tensor:
        concat = torch.cat([rgb, tir], dim=1)
        rgb_w = self.rgb_gate(concat)
        tir_w = self.tir_gate(concat)
        fused = torch.cat([rgb * rgb_w, tir * tir_w], dim=1)
        return self.refine(fused)


class CompetitiveFusionBlock(nn.Module):
    def __init__(self, channels: int) -> None:
        super().__init__()
        self.modality_embed = nn.Sequential(
            nn.Conv2d(channels * 4, channels * 2, kernel_size=1, bias=False),
            nn.BatchNorm2d(channels * 2),
            nn.ReLU(inplace=True),
        )
        self.rgb_gate = nn.Sequential(
            nn.Conv2d(channels * 2, channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.Sigmoid(),
        )
        self.tir_gate = nn.Sequential(
            nn.Conv2d(channels * 2, channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.Sigmoid(),
        )
        self.local_refine = nn.Sequential(
            nn.Conv2d(channels * 2, channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
        )
        self.channel_attention = ChannelAttention(channels)
        self.spatial_attention = SpatialAttention()
        self.output = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, rgb: torch.Tensor, tir: torch.Tensor) -> torch.Tensor:
        diff = torch.abs(rgb - tir)
        prod = rgb * tir
        fused_descriptor = self.modality_embed(torch.cat([rgb, tir, diff, prod], dim=1))
        rgb_w = self.rgb_gate(fused_descriptor)
        tir_w = self.tir_gate(fused_descriptor)
        mixed = torch.cat([rgb * (1.0 + rgb_w), tir * (1.0 + tir_w)], dim=1)
        fused = self.local_refine(mixed)
        fused = fused * self.channel_attention(fused)
        fused = fused * self.spatial_attention(fused)
        residual = 0.5 * (rgb + tir)
        return self.output(fused + residual)


class PyramidRefineBlock(nn.Module):
    def __init__(self, channels: int) -> None:
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channels),
        )
        self.channel_attention = ChannelAttention(channels)
        self.spatial_attention = SpatialAttention()
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        refined = self.block(x)
        refined = refined * self.channel_attention(refined)
        refined = refined * self.spatial_attention(refined)
        return self.relu(refined + x)


class EnhancedFPN(nn.Module):
    def __init__(self, in_channels_list: list[int], out_channels: int) -> None:
        super().__init__()
        self.fpn = FeaturePyramidNetwork(in_channels_list, out_channels, extra_blocks=LastLevelMaxPool())
        self.refine = nn.ModuleDict({str(idx): PyramidRefineBlock(out_channels) for idx in range(len(in_channels_list))})

    def forward(self, x: OrderedDict[str, torch.Tensor]) -> OrderedDict[str, torch.Tensor]:
        pyramid = self.fpn(x)
        return OrderedDict((name, self.refine[name](feature) if name in self.refine else feature) for name, feature in pyramid.items())


class RGBTBackboneWithFPN(nn.Module):
    def __init__(
        self,
        pretrained: bool = True,
        out_channels: int = 256,
        fusion_variant: str = "basic",
        neck_variant: str = "fpn",
    ) -> None:
        super().__init__()
        rgb_resnet = _make_resnet50(pretrained)
        tir_resnet = _make_resnet50(pretrained)

        return_layers = {"layer1": "0", "layer2": "1", "layer3": "2", "layer4": "3"}
        self.rgb_body = IntermediateLayerGetter(rgb_resnet, return_layers=return_layers)
        self.tir_body = IntermediateLayerGetter(tir_resnet, return_layers=return_layers)

        stage_channels = [256, 512, 1024, 2048]
        fusion_variant = fusion_variant.lower()
        fusion_cls = CompetitiveFusionBlock if fusion_variant in {"competitive", "advanced", "attention_plus"} else FusionBlock
        self.fusion = nn.ModuleList([fusion_cls(ch) for ch in stage_channels])
        neck_variant = neck_variant.lower()
        if neck_variant in {"enhanced_fpn", "refined_fpn", "competition"}:
            self.fpn = EnhancedFPN(stage_channels, out_channels)
        else:
            self.fpn = FeaturePyramidNetwork(stage_channels, out_channels, extra_blocks=LastLevelMaxPool())
        self.out_channels = out_channels

    def forward(self, rgb: torch.Tensor, tir: torch.Tensor) -> OrderedDict[str, torch.Tensor]:
        rgb_feats = self.rgb_body(rgb)
        tir_feats = self.tir_body(tir)
        fused = OrderedDict()
        for idx, key in enumerate(rgb_feats.keys()):
            fused[key] = self.fusion[idx](rgb_feats[key], tir_feats[key])
        return self.fpn(fused)
