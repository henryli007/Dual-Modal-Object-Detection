"""Model builders for UAV RGB-T detection."""

