from __future__ import annotations

import random
from typing import Tuple

import torch
from PIL import Image
from torchvision import transforms as T
from torchvision.transforms import functional as F


class RGBTTrainTransform:
    def __init__(
        self,
        horizontal_flip_prob: float = 0.5,
        multi_scale_min: float = 1.0,
        multi_scale_max: float = 1.0,
        color_jitter_rgb: float = 0.0,
        tir_gain: float = 0.0,
    ) -> None:
        self.horizontal_flip_prob = horizontal_flip_prob
        self.multi_scale_min = multi_scale_min
        self.multi_scale_max = multi_scale_max
        self.color_jitter = None
        if color_jitter_rgb > 0:
            self.color_jitter = T.ColorJitter(
                brightness=color_jitter_rgb,
                contrast=color_jitter_rgb,
                saturation=color_jitter_rgb,
                hue=min(0.5 * color_jitter_rgb, 0.1),
            )
        self.tir_gain = tir_gain

    @staticmethod
    def _clip_boxes(boxes: torch.Tensor, width: int, height: int) -> torch.Tensor:
        boxes[:, 0::2] = boxes[:, 0::2].clamp_(0, width)
        boxes[:, 1::2] = boxes[:, 1::2].clamp_(0, height)
        return boxes

    def _resize(self, rgb: Image.Image, tir: Image.Image, target: dict) -> Tuple[Image.Image, Image.Image, dict]:
        if self.multi_scale_min == 1.0 and self.multi_scale_max == 1.0:
            return rgb, tir, target
        scale = random.uniform(self.multi_scale_min, self.multi_scale_max)
        src_w, src_h = rgb.size
        dst_w = max(32, int(round(src_w * scale)))
        dst_h = max(32, int(round(src_h * scale)))
        if dst_w == src_w and dst_h == src_h:
            return rgb, tir, target
        rgb = F.resize(rgb, [dst_h, dst_w], interpolation=F.InterpolationMode.BILINEAR)
        tir = F.resize(tir, [dst_h, dst_w], interpolation=F.InterpolationMode.BILINEAR)
        if target["boxes"].numel() > 0:
            boxes = target["boxes"].clone()
            boxes[:, [0, 2]] *= dst_w / src_w
            boxes[:, [1, 3]] *= dst_h / src_h
            target["boxes"] = self._clip_boxes(boxes, dst_w, dst_h)
            if "area" in target:
                target["area"] = (boxes[:, 2] - boxes[:, 0]) * (boxes[:, 3] - boxes[:, 1])
        target["size"] = torch.tensor([dst_h, dst_w], dtype=torch.int64)
        return rgb, tir, target

    def __call__(self, rgb: Image.Image, tir: Image.Image, target: dict) -> Tuple[torch.Tensor, torch.Tensor, dict]:
        if self.color_jitter is not None:
            rgb = self.color_jitter(rgb)
        if self.tir_gain > 0:
            tir = F.adjust_brightness(tir, random.uniform(max(0.1, 1.0 - self.tir_gain), 1.0 + self.tir_gain))
        rgb, tir, target = self._resize(rgb, tir, target)
        rgb_t = F.to_tensor(rgb)
        tir_t = F.to_tensor(tir)

        if random.random() < self.horizontal_flip_prob:
            rgb_t = torch.flip(rgb_t, dims=[2])
            tir_t = torch.flip(tir_t, dims=[2])
            if target["boxes"].numel() > 0:
                boxes = target["boxes"].clone()
                width = rgb_t.shape[-1]
                boxes[:, [0, 2]] = width - boxes[:, [2, 0]]
                target["boxes"] = boxes

        return rgb_t, tir_t, target


class RGBTTestTransform:
    def __call__(self, rgb: Image.Image, tir: Image.Image, target: dict | None = None):
        rgb_t = F.to_tensor(rgb)
        tir_t = F.to_tensor(tir)
        return rgb_t, tir_t, target
