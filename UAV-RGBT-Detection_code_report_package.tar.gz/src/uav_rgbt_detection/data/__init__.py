"""Data utilities for UAV RGB-T detection."""

