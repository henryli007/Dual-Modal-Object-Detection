from __future__ import annotations

from collections import Counter
from pathlib import Path
import json


def summarize_coco(annotation_path: str | Path) -> dict:
    path = Path(annotation_path)
    payload = json.loads(path.read_text(encoding="utf-8"))
    categories = payload.get("categories", [])
    annotations = payload.get("annotations", [])
    images = payload.get("images", [])
    per_category = Counter()
    id_to_name = {item["id"]: item["name"] for item in categories}
    for ann in annotations:
        per_category[id_to_name.get(ann["category_id"], str(ann["category_id"]))] += 1
    return {
        "path": str(path),
        "num_images": len(images),
        "num_annotations": len(annotations),
        "num_categories": len(categories),
        "per_category": dict(sorted(per_category.items())),
    }
