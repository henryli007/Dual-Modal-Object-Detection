from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path

import torch
from PIL import Image
from torch.utils.data import Dataset


class RGBTDetectionDataset(Dataset):
    def __init__(
        self,
        dataset_root: str | Path,
        split: str,
        transforms=None,
    ) -> None:
        self.dataset_root = Path(dataset_root)
        self.split = split
        self.transforms = transforms
        self.rgb_dir = self.dataset_root / split / "rgb"
        self.tir_dir = self.dataset_root / split / "tir"
        self.has_annotations = split in {"train", "val"}
        self.annotation_path = self.dataset_root / split / f"{split}.json"

        self.ids: list[int] = []
        self.images: dict[int, dict] = {}
        self.annotations_by_image_id: dict[int, list[dict]] = defaultdict(list)
        self.categories: dict[int, str] = {}

        if self.has_annotations:
            payload = json.loads(self.annotation_path.read_text(encoding="utf-8"))
            self.images = {item["id"]: item for item in payload["images"]}
            self.ids = sorted(self.images)
            self.categories = {item["id"]: item["name"] for item in payload["categories"]}
            for ann in payload["annotations"]:
                self.annotations_by_image_id[ann["image_id"]].append(ann)
        else:
            self.ids = sorted(int(path.stem) for path in self.rgb_dir.glob("*.jpg"))
            self.images = {
                image_id: {"id": image_id, "file_name": f"{image_id:05d}.jpg"}
                for image_id in self.ids
            }

    def __len__(self) -> int:
        return len(self.ids)

    def _build_target(self, image_id: int, width: int, height: int) -> dict:
        anns = self.annotations_by_image_id.get(image_id, [])
        boxes = []
        labels = []
        areas = []
        iscrowd = []
        ann_ids = []
        for ann in anns:
            x, y, w, h = ann["bbox"]
            if w <= 1 or h <= 1:
                continue
            boxes.append([x, y, x + w, y + h])
            labels.append(int(ann["category_id"]))
            areas.append(float(ann.get("area", w * h)))
            iscrowd.append(int(ann.get("iscrowd", 0)))
            ann_ids.append(int(ann["id"]))

        if boxes:
            boxes_t = torch.tensor(boxes, dtype=torch.float32)
            labels_t = torch.tensor(labels, dtype=torch.int64)
            areas_t = torch.tensor(areas, dtype=torch.float32)
            iscrowd_t = torch.tensor(iscrowd, dtype=torch.int64)
        else:
            boxes_t = torch.zeros((0, 4), dtype=torch.float32)
            labels_t = torch.zeros((0,), dtype=torch.int64)
            areas_t = torch.zeros((0,), dtype=torch.float32)
            iscrowd_t = torch.zeros((0,), dtype=torch.int64)

        return {
            "boxes": boxes_t,
            "labels": labels_t,
            "image_id": torch.tensor([image_id], dtype=torch.int64),
            "area": areas_t,
            "iscrowd": iscrowd_t,
            "orig_size": torch.tensor([height, width], dtype=torch.int64),
            "size": torch.tensor([height, width], dtype=torch.int64),
            "annotation_ids": ann_ids,
        }

    def __getitem__(self, index: int):
        image_id = self.ids[index]
        file_name = self.images[image_id]["file_name"]
        rgb = Image.open(self.rgb_dir / file_name).convert("RGB")
        tir = Image.open(self.tir_dir / file_name).convert("L").convert("RGB")
        width, height = rgb.size

        target = self._build_target(image_id, width, height) if self.has_annotations else {
            "image_id": torch.tensor([image_id], dtype=torch.int64),
            "orig_size": torch.tensor([height, width], dtype=torch.int64),
            "size": torch.tensor([height, width], dtype=torch.int64),
        }

        if self.transforms is not None:
            rgb_t, tir_t, target = self.transforms(rgb, tir, target)
        else:
            rgb_t = torch.from_numpy(torch.ByteTensor(torch.ByteStorage.from_buffer(rgb.tobytes())).numpy())
            raise RuntimeError("Transforms must be provided.")

        return {"rgb": rgb_t, "tir": tir_t, "target": target, "file_name": file_name}


def collate_rgbt(batch):
    rgbs = [item["rgb"] for item in batch]
    tirs = [item["tir"] for item in batch]
    targets = [item["target"] for item in batch]
    file_names = [item["file_name"] for item in batch]
    return rgbs, tirs, targets, file_names

